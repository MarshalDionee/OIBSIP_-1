package com.BookingTrain;

public class TestTrain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Train.pnrRecord p=new Train.pnrRecord();
		System.out.println(p.getpnrNumber());
		

	}

}
